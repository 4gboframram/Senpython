"""The best Senpai to Python transpiler"""
